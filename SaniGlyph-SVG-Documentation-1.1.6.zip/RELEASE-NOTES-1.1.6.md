# SaniGlyph SVG 1.1.6 Release Notes

## Changes

- Corrected the WordPress.org `Tested up to` header from 7.0 to 7.1, resolving the `outdated_tested_upto_header` automated-scan failure.
- Bumped the release to 1.1.6 and synchronized the plugin header, runtime constant, block metadata, block asset metadata, readme stable tag, changelog, dashboard badge, screenshots, and documentation.
- Re-audited the package against the prior ShareNivo review findings: the contributor is a valid WordPress.org username, there is no arbitrary custom-code feature, there are no tracking or remote-service calls, and there is no invalid privacy-policy link.
- Rebuilt the dashboard brand mark for clear rendering at small WordPress admin sizes.
- Simplified the shield and SVG path to two large nodes with thicker, cleaner shapes.
- Removed the translucent logo tile and increased the mark's usable size and contrast.
- Updated the WordPress.org icons and banner to use the same simplified mark.
- Preserved the existing navy `#18264e`, royal blue `#3157d5`, and violet `#7145d7` visual palette.
- Added standard and high-DPI WordPress.org icons and banners as a separate asset package.
- Added four WordPress.org screenshots and matching `readme.txt` captions.
- Added a separate screenshot-based user guide and publishing guide.
- Retained the established logo and color scheme without functional UI changes.

## Packaging decision

Only the optimized 88 × 88 px dashboard logo is included in the installable plugin. WordPress.org banners, directory icons, screenshots, and user documentation are distributed separately so the plugin remains lightweight.

The documentation archive and its screenshot paths include `1.1.6` in their names so an older extracted folder or cached download cannot silently supply earlier screenshots.
