# SaniGlyph SVG 1.1.6 WordPress.org Submission Checklist

Use the clean `saniglyph-svg-1.1.6.zip` archive for the plugin upload. Do not upload the documentation or WordPress.org asset ZIP as the plugin.

## Before uploading the ZIP

- Confirm the ZIP contains one top-level folder named `saniglyph-svg`.
- Confirm `saniglyph-svg/readme.txt` says `Tested up to: 7.1` and `Stable tag: 1.1.6`.
- Confirm the main plugin header and dashboard show version 1.1.6.
- Install the official **Plugin Check** plugin on a staging WordPress 7.1 site.
- Run all available checks against SaniGlyph SVG and resolve any reported errors. Do not suppress or work around a suspected false positive; ask the Plugins Team to review it.
- Activate the plugin, save its settings, upload a safe SVG, verify an unsafe SVG is rejected, and test the shortcode/block with inline rendering enabled.

## After WordPress.org approval

The readme stable tag must correspond to an actual SVN release directory. Commit the plugin files to both `trunk` and `tags/1.1.6`; do not set the stable tag to `trunk`.

Recommended repository layout:

```text
saniglyph-svg/
├── assets/
├── tags/
│   └── 1.1.6/
└── trunk/
```

Verify the release tag after committing:

```bash
svn ls https://plugins.svn.wordpress.org/saniglyph-svg/tags/1.1.6/
```

Upload the contents of `SaniGlyph-SVG-WordPress.org-Assets-1.1.6.zip` to the repository's top-level `assets` directory, not to `trunk` or the plugin ZIP. Ensure PNG files have the `image/png` SVN MIME property:

```bash
svn propset svn:mime-type image/png assets/*.png
svn propget svn:mime-type assets/icon-256x256.png
```

WordPress.org caches directory assets. A committed icon, banner, or screenshot can take time to appear; do not reintroduce an older logo while waiting for the cache to refresh.

## Review-risk confirmations

- Contributor: `shahidirfan100`
- No arbitrary custom CSS, JavaScript, PHP, or header/footer injection
- No external services, telemetry, tracking, remote code, or third-party API
- No vendor privacy-policy URL or consent requirement
- Sanitization cannot be disabled
- SVG uploads require both an allowed role and WordPress's `upload_files` capability
- Installable ZIP excludes documentation, directory assets, tests, build tools, and development files
